/*Going ahead and collecting all the material I need to add the numbers to the website*/
let result = document.querySelector("#click-result");
const original_message = result.textContent;
let numblock = document.querySelector("#num-blocks");

/*Went ahead and made the html in order to add it in later for the html, then for every single time we go through, until
    i finally goes over 100, it will add a circle with it's own number for the id, basically, and the text for it.*/ 
let num_circles = ``;
for (let i = 1; i <= 100; i++) {
    num_circles += `<div class="number" data-circle-num="${i}">${i}</div>\n`;
}
numblock.insertAdjacentHTML("beforeend", num_circles);
/*I had to go ahead and get this to see just so, in all the numbers's cases, if they get selected, then the program should go ahead and see
    if it's equal to the randomly-generated number. The addEventListener for this case is at the end of the program*/
let numbers = document.querySelectorAll('.number');

/*Each time I loop through, and playAgain is clicked, this number is going to go up by 1. This is already going to be added to the start-block
    so it has someplace to go. It will always be on the top line. */
let round_num = 1;
document.querySelector('#start-block').insertAdjacentHTML('afterbegin', `<h1 id='round'>Round ${round_num}</h1>`);

/*Just took this from my previous code because I feel like this is a good use for it.*/
function secret_num() {
    let secret_number = Math.floor(Math.random() * 100);
    //Making sure if it's 0, it gets reassigned until it's not
    if (secret_number === 0) {
        while (secret_number === 0) {
            secret_number = Math.floor(Math.random() * 100);
        };
    };
    //this will print, but I have to end with return because if I don't, then I will get 'undefined'
    console.log('Secret number has been selected!');
    return(secret_number);
};

/*I was nervous about, if I called secret_num() alone, it would change every single time, so I went ahead and assigned it to a variable.
    Turns and highscore is for the extra-credit.*/
let secret_number = secret_num();
let turns = 0;
let highscore = 0;

/*This is the big ol' function that's just going in and seeing if it's equal to the secret_number. If it isn't, the button will be disabled,
    it will be given a different color, and the content will tell the user the number they selected and whether they're low or high. It will
    also add 1 to the turns, whether they get it right or wrong.*/
function checkNum() {
    //console.log(this.dataset.circleNum);
    if (Number(this.dataset.circleNum) > secret_number) {
        result.textContent = `${this.dataset.circleNum} is too high.`;
        this.style.backgroundColor = 'red';
        /*This part gets cited later on, but I had to call these here because I realized the user could keep clicking the button
            and add more to their score*/
        this.style.pointerEvents = 'none';
        this.disabled = true;
        turns += 1;
    }
    else if (Number(this.dataset.circleNum) < secret_number) {
        result.textContent = `${this.dataset.circleNum} is too low.`;
        this.style.backgroundColor = 'blue';
        /*Same here*/
        this.style.pointerEvents = 'none';
        this.disabled = true;
        turns += 1;
    }
    else {
        /*At the end, it will say what the secret number was and how many turns it took the user. Also went back and changed the sentence, wanted
            to be grammatically correct on whether or not it only took 1 turn (which, honestly, didn't expect when it happened to me) */
        /*When it's done, that's still one guess*/
        turns += 1;
        result.textContent = `You got it! ${this.dataset.circleNum} is the secret number.\nIt took you ${turns} turn`;
        if (turns === 1) {
            result.textContent += '.';
        }
        else {
            result.textContent += 's.';
        }
        /*When the number is guessed, the user should not be able to click on the buttons anymore, so I went through and turned them all off.*/
        numbers.forEach((number) => {
            /*I originally got .pointerEvents from here ---> 
                https://stackoverflow.com/questions/22456641/disable-non-clickable-an-html-button-in-javascript/22456719
            But I also went to here to get a better explaination and make sure it would also work for Javascript --> 
                https://developer.mozilla.org/en-US/docs/Web/CSS/pointer-events
            
            pointerEvents, from what I understand, is a function used usually for design features whenever a button is hovered over or clicked.

            I used this because, even when calling .disabled, I could still interact with the button, so I wanted to shut down the part
            via CSS. If playAgain is called, though, it'll be turned back on with auto*/
            number.style.pointerEvents = 'none';
            number.disabled = true;
        })
        /*I saw in the instructions that the max amount of rounds people should play are 10, so I wanted to make sure, so long as the round_num
            isn't equal to it, you can still hit the 'playAgain()' button. If it is at that point, though, it will not show up and just tell the user
            'Hey, ya made it, congrats'*/
        if (round_num !== 10) {
            playAgain();
        }
        else {
            document.querySelector('#click-result').insertAdjacentHTML('afterend', "<i>You made it through 10 rounds, congrats!</i>");
        }
        /*I thought about it and still wanted the user to be able to see their high score and the secret numbers generated, so the buttons will still pop up.
            Not the greatest positioning, but I like it*/
        highScore(turns);
        secretNumbers();
    }
}

/*This is simply to add the play again button whenever they go to do so*/
function playAgain() {
    document.querySelector('body').insertAdjacentHTML("beforeend", `<button id='again'>Play Again?</button>`);
    /*If it is pressed, you can click on the buttons again and they'll respond. Their colors turn back to white. All the buttons will
        be removed until you beat the game again, turns is set back to 0, the round number goes up, 
        and it will tell the user to click a number between 1 and 100.*/
    document.querySelector('#again').addEventListener('click', function(event) {
        numbers.forEach((number) => {
            number.style.pointerEvents = 'auto';
            number.disabled = false;
            number.style.backgroundColor = 'white';
            if (document.querySelector("#secrethistory")) {
                document.querySelector("#secrethistory").remove();
            }
            if (document.querySelector("#highscore")) {
                document.querySelector("#highscore").remove();
            }
        })
        document.querySelector('#again').remove();
        document.querySelector('#score').remove();
        document.querySelector('#secretNums').remove();
        turns = 0;
        round_num += 1;
        document.querySelector('#round').textContent = `Round ${round_num}`;
        secret_number = secret_num();
        result.textContent = original_message;
    })
}

/*For this part, though, it sees what high score you've gotten over time. I was going to say if it was just the first round, then highscore
    should already be set, but it wasn't working for me, so I decided to say, so long as highscore is 0 at the very start, then the first round should
    already be the high score. It's impossible to get a high score of 0, so...
Else, if the highscore is higher than the latest score, it will get reassigned. If the player clicks the button for high score, they can see it.*/
let data = document.querySelector('#data');
original_data = data;

function highScore (score) {
    document.querySelector('body').insertAdjacentHTML("beforeend", `<button id='score'>Latest<br>High Score</button>`);
    console.log(score);
    if (highscore === 0) {
        highscore = score;
    }
    else if (highscore > score) {
        highscore = score;
    }
    document.querySelector('#score').addEventListener('click', function(event) {
        data.innerHTML = "";
        let score_html = `<div id="highscore"><h4>High Score:</h4>${highscore}`;
        data.insertAdjacentHTML('beforeend', score_html);
    })
}

/*This final one just shows, for every number that is generated, it will be added to a list. If the user wants to see what was generated, they can.*/
let secretnum_history = [];
function secretNumbers() {
    secretnum_history.push(secret_number);
    document.querySelector('body').insertAdjacentHTML("beforeend", `<button id='secretNums'>See what numbers<br>were generated</button>`);
    document.querySelector('#secretNums').addEventListener('click', function(event) {
        data.innerHTML = "";
        let secret_num_html = '<div id="secrethistory"><h4>These are the secret numbers you guessed before:</h4><br>';
        for (let num of secretnum_history) {
            /*This is just for grammar-ish stuff*/
            if (secretnum_history.indexOf(num) !== secretnum_history.length - 1) {
                secret_num_html += `${num}, `;
            }
            else {
                secret_num_html += `${num}`;
            }
        }
        secret_num_html += "</div>";
        data.insertAdjacentHTML('beforeend', secret_num_html);
    });
}

/*Finally, this is the button that says, if any of the numbers in the object, numbers, is pressed, it should execute checkNum, where a majority
    of the functions and callbacks are.*/
numbers.forEach((number) => {
    number.addEventListener('click', checkNum);
})