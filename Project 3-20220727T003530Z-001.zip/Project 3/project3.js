"use strict";
console.log('Javascript is running!');

/*These are all the questions I was able to come up with. I know they're not the greatest, I can't think of good stuff when on the spot TTnTT*/
let questions = [
  {
    question: "What was the first building in the world to have more than 100 floors?",
    answers: {
      a: "Chrysler Building",
      b: "Empire State Building",
      c: "Woolworth Building",
    },
    correct: "b",
  },
  {
    question: "Who plays Aziraphale in the show, <i>Good Omens?</i>",
    answers: {
      a: "Michael Sheen",
      b: "Jon Hamm",
      c: "David Tennant",
    },
    correct: "a",
  },
  {
    question: "What was Isabelle from <i>Animal Crossing</i> originally going to be?",
    answers: {
      a: "A deer",
      b: "A chipmunk",
      c: "Still a dog",
    },
    correct: "c",
  },
  {
    /*This literally came out two months ago, it was very weird*/
    question: "What is Grimace from McDonald's supposed to be?",
    answers: {
      a: "A chicken nugget",
      b: "A taste bud",
      c: "A monster",
    },
    correct: "b",
  },
  {
    question: "What candy did the main characters of <i>Ed, Edd, & Eddy</i> always go after?",
    answers: {
      a: "Lemon drops",
      b: "Jawbreakers",
      c: "Gumballs",
    },
    correct: "b",
  },
];

/*I'm going ahead and grabbing the main content of the quiz, that being the place where the user will select their answers. For a majority of
  this stuff, there will be some console logging to make sure querySelector is able to get what it needs. I can't remember the difference between
  using #quiz and .quiz, but I remember the last one was able to grab it last time*/
let question_html = document.querySelector('.quiz');
//console.log(question_html);
let html = [];
let html_str = '';

/*Instead of having this in the main code, I wanted to go ahead and make a function to practice a bit, and I want to aim to have very little
  in my main code.
Basically this is just looking at every single question within the dictionary, as well as each answer within it, and it will assign all the
  attributes each part needs, as well as setting up the text correctly to put into the HTML.
*/
function setQuestions() {
  for (let question of questions) {
    //console.log(question);
    html_str += `<p><b id="Q${questions.indexOf(question)+1}">${questions.indexOf(question)+1}.) ${question['question']}</b><br>`;
    for (let answer in question.answers) {
      //console.log(answer);
      html_str += `<input type='radio' id='choice_${answer}' name='${questions.indexOf(question)+1}' value='${answer}'>
      <label for='choice_${answer}'>${question.answers[answer]}</label><br>`;
    }
    //html.push(html_str);
    html_str += `</p>`;
  }
  return html_str;
}
question_html.insertAdjacentHTML('beforeend', setQuestions());

let seconds = 0;
function timer() {
  seconds += 1;
  document.querySelector("[type='time']").value = seconds;
}

/*For this function, I wanted to go ahead and say when it's checking the answers just to make sure that it's actually working. Otherwise, I'll
  be keeping the total score within this function and, for every single question that matches up with question.correct, it will add one to it.
  At the end, it should change the total score in the code to however many the user got.*/
//Ended up having to put score on the outside because I forgot I'll have to set it back to 0 at the end.
let score = 0;
function checkAnswers() {
  //console.log(document.querySelector('.score'));
  let user_answers = question_html.querySelectorAll('input');
  //console.log(user_answers);
  //let i = 1;
  for (let guess of user_answers) {
    //console.log(guess);
    //console.log(questions.indexOf(guess));
    let position = Number(guess.name) - 1;
    if (guess.checked && guess.value === questions[position]['correct']) {
      //console.log('true');
      //console.log(guess);
      //console.log(guess.value);
      //console.log(questions[guess.name]['correct']);
      //console.log(guess.value === questions[position]['correct']);
      score += 1;
    }
  }
  console.log('answers graded');
  return score;
}

/*This will just grab all the radio buttons again and, for every single one, it will make it clickable again, as well as make sure
  they aren't checked anymore.*/
function playAgain() {
  let buttons = document.querySelectorAll('[type="radio"]');
  for (let button of buttons) {
    button.disabled = false;
    button.checked = false;
  }
  document.querySelector('#playagain').remove();
  document.querySelector('#score_label').remove();
  score = 0;
}

/*I only need to grab a button because I'm pretty sure this is the only button that exists within the entire HTML page. At least, for the default.
  Whenever it's clicked, that must mean the user wants to know what answers they got right, so it should go ahead and check all of them 
  within the function.*/
let check_answers = document.querySelector('#score-btn');
//console.log(check_answers);
/*while (!(check_answers.clicked == true)) {
  setInterval(timer(), 1000);
}*/
check_answers.addEventListener('click', function() {
  console.log('checking answers...');
  let total_score = checkAnswers();
  document.querySelector('.score').insertAdjacentHTML('beforeend', `<span id="score_label">${total_score}/${questions.length}</span>`);
  let buttons = document.querySelectorAll('[type="radio"]');
  //console.log(buttons);
  /*I wanted to go ahead and disable all the buttons at the end because I'm gonna assume they shouldn't be able to select the buttons
    unless they click the 'play again' button. Also I don't want it to mess up the score.*/
  for (let button of buttons) {
    button.disabled = true;
  }
  document.querySelector('.buttons').insertAdjacentHTML('beforeend',  `<br><button id="playagain">Play Again?</button>`);
  /*This has to go in here since the 'play again' button should only appear when the 'check answers' button is pressed. Otherwise it will
    run into an error.*/
  let again = document.querySelector('#playagain');
  again.addEventListener('click', playAgain);
})