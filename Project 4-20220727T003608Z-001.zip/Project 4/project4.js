/*Grabbing the buttons I need for the event listeners and saying that the website is active*/
console.log('website active');

const search_button = document.querySelector('#search');
const random_button = document.querySelector('#random');
//console.log(search_button, random_button);

/*This was my original function at the very start, but I realized this wouldn't work since it wasn't async, so I commented it out*/
/*const findRecipe(recipe) {
    const response = await fetch(`www.themealdb.com/api/json/v1/1/search.php?s=${recipe}`);
    return response;
}*/
/*The first part just goes ahead and grabs the link, puts in the recipe the user is searching for, and then uses .json to make sure
    it's able to access everything it needs to. In order to access the results, I had to use recipes.meals instead. This is where I found
    a lot of different results that could pop up when it came to the meal results - some were null, others could be undefined, etc., so I tried
    to prepare for all those scenarios. I don't think I caught them all, but I'm glad I was able to run into the few that popped up.*/
const findRecipe = async recipe => {
    //console.log(recipe);
    const response = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${recipe}`);
    //console.log(response.ok);
    //console.log(response);

    const recipes = await response.json();
    //console.log(recipes);
    //console.log(recipes.meals[0].strMealThumb);
    /*I forgot a user might try to look up a recipe that has no results, so I wanted to let the user know. This just fills in the .info
        slot and say there's no results.*/
    if (recipes.meals == null) {
        document.querySelector('.info').innerHTML = 'No results';
    }
    /*If there are results, though, I went ahead and made a variable to store the information. For every single recipe that is within meals,
        it goes ahead and adds the name and the image to it. After, it puts it in the .info slot. */
    else {
        let recipe_details = ``;
        for (let recipe of recipes.meals) {
            //console.log(recipe);
            recipe_details += `<div>\
            <div class="recipe-desc" id="${recipe.strMeal}">\
            <h1>${recipe.strMeal}</h1>\
            <img src="${recipe.strMealThumb}">
            </div>\
            </div><br>`;
        }
        document.querySelector('.info').innerHTML = recipe_details;

        /*I went to the office hour session for this, and I did originally try to make this work outside of everything, but it only returned
            promises. I think it was because it wasn't actually able to access everything it needed to when outside of this function, so
            it had to be put in here. Also, I did try having the pullUpRecipe part in the function place instead, but that also ran into errors,
            so I had to do it this way. */
        let recipe_buttons = document.querySelectorAll(".recipe-desc");
        //console.log(recipe_buttons);
        recipe_buttons.forEach(recipe => {
            //console.log(recipe);
            recipe.addEventListener('click', function() {
                pullUpRecipe(recipe, recipes.meals);
            });
        })
        //return(recipes.meals);
    }
}

/*This took me the longest time to complete, especially for ingredients, because for some reason, it wouldn't work like I thought it would.
    But after a while, I was able to get everything to work, the only thing I couldn't fix was whether there were keywords like 'STEP #' or anything
    like that. I know I could do regular expressions, but I was trying to replace some key words instead, since I noticed there were /r's and /n's
    within the text. I thought if I just replaced either of those with <br>, it would work, but I guess not? I wanted to try and use regular expressions,
    but I couldn't quite think of how to make it work, so I gave up after a while. I'm not the greatest with those.*/
function pullUpRecipe(recipe_name, recipe_list) {
    /*console.log('hi');
    console.log(recipe_name.id);
    console.log(recipe_list);*/
    let recipe_info = ``;
    //strArea, strInstructions (x), strIngredient# and strMeasure#, strYoutube, strSource, strCategory
    //LOOK OUT FOR RECIPES WITH STEPS
    for (let i of recipe_list) {
        //I wanted to grab the recipe list I got from earlier and make sure that whatever result I found was the one the user is pulling up
        //I probably could have just done i[recipe_name.id], but I think I would run into the same problem as below.
        if (recipe_name.id == i.strMeal) {
            //console.log(i);
            //console.log('true');

            let ingredients_div = `<div class="ingredients">`;
            let instructions_div = `<div class="instructions">`;
            //This...caused me so much troble. I initially tried to make a variable called 'keys' with this exact format (Object.keys(i)), but no matter what I
            //  did, I kept getting undefined. I don't remember when I thought of it, but then I decided to just do the Object.keys parts
            //  in each spot instead, and it seemed to work there? I'm still not entirely sure why this works but the other doesn't,
            //  but I'm just glad this works. I also did some error checking since I saw some ingredients be empty or null, and those values
            //  showed up in the recipe part, so I wanted to make sure those don't get added at all.
            for (let key in Object.keys(i)) {
                //console.log(key);
                if ((Object.keys(i)[key].includes('strIngredient')) && ((i[Object.keys(i)[key]] !== "") && (i[Object.keys(i)[key]] !== null))){
                    //console.log(key);
                    //console.log(i[Object.keys(i)[key]]);
                    //This is a pretty funky part, but what I was trying to do here is match the last one or two numbers of the measurement
                    //  with the ingredient. I saw they matched up according to the number, so had to make sure that worked. Then after a while,
                    //  I noticed I only did it for the last number, which would give weird results like 'Coconut milk - 1 diced,' which doesn't
                    //  make sense at all. I did try to do things like (-2, -1), but that didn't work, so I just decided to make a variable equal
                    //  to the -2 and forward, which should just give the last two characters of the key, strIngredient#. Then, if the entire
                    //  thing wasn't a number for that case (i.e.: I have something like 't1' instead of just '1'), I would edit measure
                    //  to just be 1 in that case instead. If they're both numbers though, like 21, then it's fine.
                    let measure = 'strMeasure' + Object.keys(i)[key].slice(-2);
                    if (!(Number(measure[measure.length - 2]))) {
                        measure = 'strMeasure' + Object.keys(i)[key].slice(-1);
                    }
                    //console.log(i[measure]);
                    //This is also just checking to make sure that measurements are also not empty or anything. I know in some of the recipes, they
                    //  could just be undefined, so I didn't want the html to show a dash, then just undefined. For all I know, there's probably a 
                    //  measurement that has a null somewhere, but I haven't run into that whenever I randomize a recipe. 
                    if (typeof(i[measure]) !== 'undefined') {
                        ingredients_div += `${i[Object.keys(i)[key]]} - ${i[measure]}<br>`;
                    }
                    else {
                        ingredients_div += `${i[Object.keys(i)[key]]}<br>`;
                    }
                    //console.log(measure);
                }
            }
            //this just adds an ending div tag at the end for both cases for formatting sake
            ingredients_div += `</div>`;
            let instructions = i.strInstructions
            //console.log(instructions);
            instructions_div += `${instructions}</div>`
            //console.log(ingredients_div);

            //Then this grabs all the info needed for the recipe - the name in capital letters (I wanted to do a title format, but couldn't figure
            //  that out), the picture, various information like where it's from and where to find a tutorial video, the ingredients, and the instructions!
            recipe_info += `
            <div class="recipe-info">\
                <h2>${i.strMeal.toUpperCase()}</h2>
                <img src="${i.strMealThumb}">
                <div class="info">
                    <b><i>${i.strArea}&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                    ${i.strCategory}&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                    <a href="${i.strSource}">Source</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                    <a href="${i.strYoutube}">Instructions Video</a></i></b>
                </div><br><br>
                ${ingredients_div}<br><hr>
                ${instructions_div}
            </div>`;
                /*    ${i.strIngredient1}
                </div><hr>
                <div class="instructions">
                    ${i.strInstructions}
                </div>`;*/
        }
    }
    //When the recipe_info has everything it needs, it gets put in the innerHTML
    document.querySelector('.info').innerHTML = recipe_info;
}

/*For this part, I was trying to think of a way to make this work on it's own, but I couldn't exactly get it to work, so I decided
    to make it easier on me by just grabbing the recipe, getting the name, and plugging it into the findRecipe function. I know this doesn't
    just take you to the page of the recipe and show the details there, but it does randomly generate only one result.*/
const randomizeRecipe = async recipe => {
    const response = await fetch("https://www.themealdb.com/api/json/v1/1/random.php");
    //console.log(response.ok);
    const recipes = await response.json();
    //console.log(recipes);
    let food_name = recipes.meals[0].strMeal;
    //console.log(food_name);
    findRecipe(food_name);
}


/*These are just the buttons to grab everything. Search looks to see what value the search bar has, then applies it to findRecipe. Random
    just calls the function, where the same thing (kind of) happens. */
search_button.addEventListener('click', function() {
    let searching_recipes = document.querySelector("[type='text']");
    //console.log(searching_recipes.value);
    findRecipe(searching_recipes.value);

    /*recipe_buttons.forEach((recipe) => {
        console.log(recipe)
        recipe.addEventListener('click', console.log('hi'));
    })*/
});
random_button.addEventListener('click', function() {
    randomizeRecipe();
})